
nEtaBins=10
for iBin in range (0, nEtaBins) :
    print iBin
